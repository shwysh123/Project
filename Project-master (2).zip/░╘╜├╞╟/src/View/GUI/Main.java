package View.GUI;

public class Main {
	public static void main(String[] args)  {
		new MAINGUI();
	}
}