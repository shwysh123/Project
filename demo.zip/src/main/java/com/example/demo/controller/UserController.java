package com.example.demo.controller;

import com.example.demo.domain.dto.UserDto;
import com.example.demo.domain.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

@Controller
public class UserController {

    private UserService userService;

    @GetMapping("/join")
    public void join_get(){
        log.info("GET/join");
        }
    @PostMapping("/join")
        public String join_post(@Valid UserDto dto, BindingResult bindingResult, Model model, HttpServletRequest request, HttpServletResponse response){
            log.info("GET/join"+dto);

            //01

            //02
            if(bindingResult.hasFieldErrors()){
                for(FieldError error : bindingResult.getFieldErrors()){
                    log.info(error.)
                }

            }
    }
}
