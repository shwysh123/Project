package com.example.demo.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Reply {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long rnumber;           //rno댓글번호   bno 게시물 번호
    @ManyToOne
    @JoinColumn(name = "rnumber", foreignKey = @ForeignKey(name = "FK_reply_board", foreignKeyDefinition = "FOREIGN KEY (rnumber) REFERENCES board(number) ON DELETE CASCADE")) //FK 설정
    private Board board;
    private String nickname;
    private String content;
    private LocalDateTime date;
}
