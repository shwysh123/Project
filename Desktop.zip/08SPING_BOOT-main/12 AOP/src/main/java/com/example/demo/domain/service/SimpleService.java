package com.example.demo.domain.service;

import org.springframework.stereotype.Service;

@Service
public class SimpleService {
	

	public void get1() {
		System.out.println("SimpleService get1..");
	}
	
	public void get2() {
		System.out.println("SimpleService get2..");
	}
	
	public void get3() {
		System.out.println("SimpleService get3..");
	}
}
