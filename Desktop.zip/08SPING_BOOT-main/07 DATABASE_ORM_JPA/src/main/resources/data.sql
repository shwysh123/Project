INSERT INTO `bookdb`.`tbl_a` (`id`, `text`) VALUES ('1', 'a');
INSERT INTO `bookdb`.`tbl_a` (`id`, `text`) VALUES ('2', 'b');
INSERT INTO `bookdb`.`tbl_a` (`id`, `text`) VALUES ('3', 'c');
INSERT INTO `bookdb`.`tbl_a` (`id`, `text`) VALUES ('4', 'd');
INSERT INTO `bookdb`.`tbl_a` (`id`, `text`) VALUES ('5', 'e');
