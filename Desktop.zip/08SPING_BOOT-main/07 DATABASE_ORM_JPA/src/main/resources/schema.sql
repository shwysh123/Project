create table if not exists tbl_a
(
	id int primary key,
    text varchar(255)
);