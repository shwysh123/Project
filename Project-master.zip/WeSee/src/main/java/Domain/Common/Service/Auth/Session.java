package Domain.Common.Service.Auth;

public class Session {

}
