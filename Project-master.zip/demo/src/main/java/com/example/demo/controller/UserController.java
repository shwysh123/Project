package com.example.demo.controller;

import com.example.demo.domain.dto.UserDto;
import com.example.demo.domain.entity.Board;
import com.example.demo.domain.entity.User;
import com.example.demo.domain.repository.BoardRepository;
import com.example.demo.domain.repository.UserRepository;
import com.example.demo.domain.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.Properties;

@Controller
@Slf4j
public class UserController {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private UserService userService;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private BoardRepository boardRepository;


    @PostMapping("/login")
    public String login_post(@RequestParam("email") String email, @RequestParam("password") String password, HttpSession session, Model model) {
        log.info("GET/login");


        return "redirect:/list";
    }



    @GetMapping("/join")
    public void join_get(){
        log.info("GET/join");
        }
    @PostMapping("/join")
        public String join_post(@Valid UserDto dto, BindingResult bindingResult, Model model, HttpServletRequest request, HttpServletResponse response){
            log.info("GET/join"+dto);

            //01

            //02
            if(bindingResult.hasFieldErrors()){
                for(FieldError error : bindingResult.getFieldErrors()){
                    log.info(error.getField()+ " : " + error.getDefaultMessage());
                    model.addAttribute(error.getField(), error.getDefaultMessage());
                }
        return "/join";
            }
            //03
        dto.setRole("ROLE_MEMBER");
            dto.setPassword(passwordEncoder.encode(dto.getPassword()));
        User user = new User();

        user.setEmail(dto.getEmail());
        user.setPassword(dto.getPassword());
        user.setNickname(dto.getNickname());
        user.setName(dto.getName());
        user.setZipcode(dto.getZipcode());
        user.setAddr1(dto.getAddr1());
        user.setAddr2(dto.getAddr2());
        user.setBirth(dto.getBirth());
        user.setPhone(dto.getPhone());

        user.setProvider(dto.getProvider());
        user.setProviderId(dto.getProviderId());
        user.setRole(dto.getRole());

        userRepository.save(user);

        boolean isjoin = userService.joinMember(dto,model,request);
            if(!isjoin){
                return "/join";
            }
            //04
        return "redirect:/login?msg=Join_Success!";
    }
    //---------------------------------------
    //메일인증
    //---------------------------------------
    @GetMapping(value="/auth/email/{email}")
    public @ResponseBody void email_auth(@PathVariable String email, HttpServletRequest request){
        log.info("GET/user/auth/email.."+email);

        //메일설정
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost("smtp.gmail.com");
        mailSender.setPort(587);
        mailSender.setUsername("shwysh123@naver.com");
        mailSender.setPassword("dhrgml!8sus");

        Properties props = new Properties();
        props.put("mail.smtp.auth","true");
        props.put("mail.smtp.starttls.enable","true");
        mailSender.setJavaMailProperties(props);

        //난수값생성
        String tmpPassword = (int)(Math.random()*10000000) +"";
        //본문내용 설정
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("[WEB_INFO] 이메일 코드발송");
        message.setText(tmpPassword);

        //발송
        mailSender.send(message);
        //세선에 Code저장
        HttpSession session = request.getSession();
        session.setAttribute("email_auth_code", tmpPassword);
    }

    @GetMapping("/auth/confirm/{code}")
    public @ResponseBody String email_auth_confirm(@PathVariable String code, HttpServletRequest request){
        System.out.println("GET/user/auth/cofirm " + code);
        HttpSession session = request.getSession();
        String auth_code = (String)session.getAttribute("email_auth_code");
        if(auth_code!=null)
        {
            if(auth_code.equals(code)){
                session.setAttribute("is_email_auth",true);
                return "success";
            }else{
                session.setAttribute("is_email_auth", false );
                return "failure";
            }
        }
        return "failure";
    }


}
